export { fetchAnalytics } from './queries/analytics';
