export interface GroqModel {
  id: string;
  name: string;
  description: string;
  maxTokens: number;
}
